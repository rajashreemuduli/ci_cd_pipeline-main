package com.testAuth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCiCdApplicationTests {

	@Test
	void contextLoads() {
	}

}
